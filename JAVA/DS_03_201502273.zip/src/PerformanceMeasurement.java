import java.util.Random;

public class PerformanceMeasurement {
	private static final int size = 1000;
	private SortedArrayBag arrBag;
	private SortedLinkedBag linkedBag;
	private Random rand;
	private int[] data;
	private long startTime, endTime, insertingTime, findingMaxTime;
	
	public PerformanceMeasurement() {
		
	}
	
	public void generateData() {
		data = new int[5000];
		rand = new Random();
		rand.setSeed(System.currentTimeMillis());
		for(int i = 0; i < data.length; i++) {
			data[i] = rand.nextInt(1000000);
		}
	}
	
	public void testSortedArrayBag() {
		System.out.println("{Sorted Array}");
		
		for(int i = 1; i < 6; i++) {
			this.arrBag = new SortedArrayBag(size * i);
			this.startTime = System.nanoTime();
			for(int j = 0; j < i * size; j++) {
				this.arrBag.add(data[j]);
			}
			this.endTime = System.nanoTime();
			this.insertingTime = this.endTime - this.startTime;
			
			this.startTime = System.nanoTime();
			for(int j = 0; j < i * size; j++) {
				this.arrBag.max();
			}
			this.endTime = System.nanoTime();
			this.findingMaxTime = this.endTime - this.startTime;
			
			System.out.println("Size " + i * size + ",\t insertion " + this.insertingTime + "\t Search Max " + this.findingMaxTime);
		}
	}
	
	public void testSortedLinkedBag() {
		System.out.println("{Sorted Linked}");
		
		for(int i = 1; i < 6; i++) {
			this.linkedBag = new SortedLinkedBag(size * i);
			this.startTime = System.nanoTime();
			for(int j = 0; j < i * size; j++) {
				this.linkedBag.add(data[j]);
				//this.linkedBag.print();
			}
			this.endTime = System.nanoTime();
			this.insertingTime = this.endTime - this.startTime;
			
			this.startTime = System.nanoTime();
			for(int j = 0; j < i * size; j++) {
				this.linkedBag.max();
			}
			this.endTime = System.nanoTime();
			this.findingMaxTime = this.endTime - this.startTime;
			
			System.out.println("Size " + i * size + ",\t insertion " + this.insertingTime + "\t Search Max " + this.findingMaxTime);
		}
	}
}
