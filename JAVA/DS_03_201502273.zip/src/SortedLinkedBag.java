
public class SortedLinkedBag extends LinkedBag {

	public SortedLinkedBag(int maxSize) {
		super(maxSize);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean add(int value) {
		// TODO Auto-generated method stub
		if(this.isFull()) {
			System.out.print("\n����\n");
			return false;
		} else if(this.isEmpty()){
			this.next = new Node<Coin>(new Coin(value));
			this.curSize++;
			return true;
		} else {
			Node<Coin> curr = this.next;
			Node<Coin> prev = null;
			Node<Coin> temp = new Node<Coin>(new Coin(value));
			
			while(curr != null) {
				if(curr.getValue().getValue() >= value) {
					if(prev == null) {
						temp.setNext(curr);
						this.next = temp;
					} else {
						temp.setNext(curr);
						prev.setNext(temp);
					}
					this.curSize++;
					return true;
				}
				prev = curr;
				curr = curr.getNext();
			}
			prev.setNext(temp);
			return true;
		}
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		if(this.next != null)
			this.next.print();
		else
			System.out.println("EMPTY");
	}
	
	
	
	

}
